<?php
include("db.php");

if (isset($_POST['id'])) {
    $deptID = (int)$_POST['id'];

    // Delete the record
    $sql = "DELETE FROM tbldepartmentmaster WHERE deptID = :deptID";
    $command = $conn->prepare($sql);
    $command->bindParam(':deptID', $deptID);
    $command->execute();

    echo "success"; // Indicate success
} else {
    echo "No ID provided"; // Handle error
}
?>
