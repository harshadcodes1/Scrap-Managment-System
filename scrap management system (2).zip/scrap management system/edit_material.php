<?php
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $materialid = $_POST['materialID'];
    $materialname = $_POST['materialName'];
    $materialdescription = $_POST['materialDescription'];
    $location = $_POST['location'];
    $category = $_POST['category'];
    $openingstock = $_POST['openingStock'];

    $sql = "UPDATE tblmaterialmaster 
            SET materialName = :materialname, materialDescription = :materialdescription, location = :location, category = :category, openingStock = :openingstock
            WHERE materialID = :materialid";
    $command = $conn->prepare($sql);
    $command->bindParam(':materialid', $materialid);
    $command->bindParam(':materialname', $materialname);
    $command->bindParam(':materialdescription', $materialdescription);
    $command->bindParam(':location', $location);
    $command->bindParam(':category', $category);
    $command->bindParam(':openingstock', $openingstock);
    $command->execute();

    header("Location: cat_master.php");
} else {
    $id = $_GET['id'];
    $sql = "SELECT * FROM tblmaterialmaster WHERE materialID = :id";
    $command = $conn->prepare($sql);
    $command->bindParam(':id', $id);
    $command->execute();
    $row = $command->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><b>Edit Material</b></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-4">
        <h3>Edit Material</h3>
        <form id="editmaterial" method="POST" action="edit_material.php">
            <input type="hidden" name="materialID" value="<?php echo $row['materialID']; ?>">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="materialName">Material Name</label>
                    <input type="text" class="form-control" id="materialName" name="materialName" value="<?php echo $row['materialName']; ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="materialDescription">Material Description</label>
                    <input id="materialDescription" class="form-control" name="materialDescription" value="<?php echo $row['materialDescription']; ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="location">Material Location</label>
                    <select id="location" class="form-control" name="location" required>
                        <option value="Open scrap" <?php if($row['location'] == 'Open scrap') echo 'selected'; ?>>Open scrap</option>
                        <option value="High Value Scrap" <?php if($row['location'] == 'High Value Scrap') echo 'selected'; ?>>High Value Scrap</option>
                    </select>
                </div>
                <div class="form-group col-md-3">
                    <label for="category">Material Category</label>
                    <select id="category" class="form-control" name="category" required>
                        <option value="Processed Scrap" <?php if($row['category'] == 'Processed Scrap') echo 'selected'; ?>>Processed Scrap</option>
                        <option value="Components Scrap" <?php if($row['category'] == 'Components Scrap') echo 'selected'; ?>>Components Scrap</option>
                    </select>
                </div>
                <div class="form-group col-md-3">
                    <label for="openingStock">Opening Stock</label>
                    <input type="text" class="form-control" id="openingStock" name="openingStock" value="<?php echo $row['openingStock']; ?>" required>
                </div>
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success" id="saveBtn">Save</button>
                    </div>
                    <div class="form-group col-md-3">
                        <button type="submit" href="cat_master.php" class="btn btn-secondary">Cancle</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
