<?php
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $materialid = $_POST['id'];

    $sql = "DELETE FROM tblmaterialmaster WHERE materialID = :materialID";
    $command = $conn->prepare($sql);
    $command->bindParam(':materialID', $materialid);

    if ($command->execute()) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
