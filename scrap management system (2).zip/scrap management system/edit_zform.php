<?php
include("navbar.php");
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $zFormID = $_POST['zFormID'];
    $zFormNo = $_POST['zFormNo'];
    $FormDate = $_POST['FormDate'];
    $userID = $_POST['userID'];
    $stLocationID = $_POST['stLocationID'];
    $location = $_POST['location'];
    $category = $_POST['category'];

    // Update the record in the database
    $sql = "UPDATE tblzForm SET zFormNo = :zFormNo, FormDate = :FormDate, userID = :userID, stLocationID = :stLocationID, location = :location, category = :category WHERE zFormID = :zFormID";
    $command = $conn->prepare($sql);
    $command->bindParam(':zFormID', $zFormID);
    $command->bindParam(':FormNo', $zFormNo);
    $command->bindParam(':FormDate', $FormDate);
    $command->bindParam(':userID', $userID);
    $command->bindParam(':stLocationID', $stLocationID);
    $command->bindParam(':location', $location);
    $command->bindParam(':category', $category);
    $command->execute();

    header("Location: zform.php");
    exit();
}

// Fetch the record to be edited
if (isset($_GET['id'])) {
    $zFormID = $_GET['id'];
    $sql = "SELECT * FROM tblzForm WHERE zFormID = :zFormID";
    $command = $conn->prepare($sql);
    $command->bindParam(':zFormID', $zFormID);
    $command->execute();
    $record = $command->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Z Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h3>Edit Z Form</h3>
        <form id="editZform" method="POST" action="edit_zform.php">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="zFormID">Z Form ID</label>
                    <input type="text" class="form-control" id="zFormID" name="zFormID" value="<?php echo htmlspecialchars($record['zFormID']); ?>" readonly>
                </div>
                <div class="form-group col-md-3">
                    <label for="zFormNo">Z Form No</label>
                    <input type="text" class="form-control" id="zFormNo" name="zFormNo" value="<?php echo htmlspecialchars($record['zFormNo']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="FormDate">Date</label>
                    <input type="date" class="form-control" id="FormDate" name="FormDate" value="<?php echo htmlspecialchars($record['FormDate']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="userID">User ID</label>
                    <input type="text" class="form-control" id="userID" name="userID" value="<?php echo htmlspecialchars($record['userID']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="stLocationID">Storage Location ID</label>
                    <input type="text" class="form-control" id="stLocationID" name="stLocationID" value="<?php echo htmlspecialchars($record['stLocationID']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="location">Location</label>
                    <select id="location" class="form-control" name="location" required>
                        <option <?php if ($record['location'] == "Storage Location") echo "selected"; ?>>Storage Location</option>
                        <option <?php if ($record['location'] == "Open Scrap") echo "selected"; ?>>Open Scrap</option>
                        <option <?php if ($record['location'] == "High Value Scrap") echo "selected"; ?>>High Value Scrap</option>
                    </select>
                </div>
                <div class="form-group col-md-3">
                    <label for="category">Category</label>
                    <select id="category" class="form-control" name="category" required>
                        <option <?php if ($record['category'] == "processed") echo "selected"; ?>>processed</option>
                        <option <?php if ($record['category'] == "Components") echo "selected"; ?>>Components</option>
                    </select>
                </div>
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                    <div class="form-group col-md-3">
                        <a href="zform.php" class="btn btn-warning">Cancel</a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
