<?php
require('C:\wamp\www\my project\Scrap management system\db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $psid = $_POST['psid'];
    $username = $_POST['username'];
    $password = $_POST['defaultPassword'];
    $role = $_POST['selectRole'];
    $dept_code = $_POST['deptCode'];
    $dept_name = $_POST['deptName'];
    $isid = $_POST['isid'];
    $isname = $_POST['isname'];

    $query = "INSERT INTO user_master (psid, username, password, role, dept_code, dept_name, isid, isname) 
              VALUES ('$psid', '$username', '$password', '$role', '$dept_code', '$dept_name', '$isid', '$isname')";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':psid', $psid);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);
    $stmt->bindParam(':role', $role);
    $stmt->bindParam(':dept_code', $dept_code);
    $stmt->bindParam(':dept_name', $dept_name);
    $stmt->bindParam(':isid', $isid);
    $stmt->bindParam(':isname', $isname);
    
    if ($stmt->prepare($stmt)) {
        // Fetch all users
        $query_all_users = "SELECT * FROM user_master";
        $stmt_all_users = $conn->query($query_all_users);

        // Output all users as JSON for AJAX response
        $users = $stmt_all_users->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($users);
    } 
}
?>
