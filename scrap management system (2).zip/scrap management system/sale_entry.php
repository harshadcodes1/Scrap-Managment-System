<?php
include('navbar.php');
include('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action == 'add') {
        // Get form data
        $saleDate = $_POST['saleDate'];
        $qty = $_POST['qty'];
        $invoiceNo = $_POST['invoiceNo'];
        $vendorName = $_POST['vendorName'];
        $material = $_POST['material'];

        // Insert form data into the database
        $sql = "INSERT INTO tblsaledetails (saleDate, qty, invoiceNo, vendorName, material)
                VALUES (:saleDate, :qty, :invoiceNo, :vendorName, :material)";
        $command = $conn->prepare($sql);
        $command->bindParam(':saleDate', $saleDate);
        $command->bindParam(':qty', $qty);
        $command->bindParam(':invoiceNo', $invoiceNo);
        $command->bindParam(':vendorName', $vendorName);
        $command->bindParam(':material', $material);
        $command->execute();
    }

    // Redirect to the same page to prevent resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Fetch data from the database
$sql = "SELECT * FROM tblsaledetails";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sale Entry</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

</head>
<body>
    <div class="container mt-4">
        <h3>Sale Entry</h3>
        <form method="POST" id="saleForm">
            <input type="hidden" name="saleID" id="saleID">
            <input type="hidden" name="action" id="action" value="add">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="saleDate">Sale Date</label>
                    <input type="date" class="form-control" id="saleDate" name="saleDate" placeholder="dd-mm-yyyy">
                </div>
                <div class="form-group col-md-3">
                    <label for="invoiceNo">Invoice No</label>
                    <input type="text" class="form-control" id="invoiceNo" name="invoiceNo">
                </div>
                <div class="form-group col-md-3">
                    <label for="material">Material</label>
                    <input type="text" class="form-control" id="material" name="material">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="qty">Quantity</label>
                    <input type="text" class="form-control" id="qty" name="qty">
                </div>
                <div class="form-group col-md-3">
                    <label for="vendorName">Vendor</label>
                    <input type="text" class="form-control" id="vendorName" name="vendorName">
                </div>
            </div>
            <div class="form-row container mt-4">
                <div class="form-group col-md-3">
                    <button type="submit" class="btn btn-success" id="saveBtn">Save</button>
                </div>
                
            </div>
        </form>
        <div class="container mt-4">
            <h3>Entries</h3>
            <table class="table table-striped" id="tblsaledetails">
                <thead>
                    <tr>
                        <th>Sale ID</th>
                        <th>Sale Date</th>
                        <th>Quantity</th>
                        <th>Invoice No</th>
                        <th>Vendor Name</th>
                        <th>Material</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($result)) {
                        foreach ($result as $row) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row["saleID"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["saleDate"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["qty"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["invoiceNo"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["vendorName"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["material"]) . "</td>";
                            echo "<td>";
                            echo "<button class='btn btn-warning edit-btn' data-id='" . htmlspecialchars($row["saleID"]) . "'><i class='fas fa-edit'></i></button> ";
                            echo "<button class='btn btn-danger delete-btn' data-id='" . htmlspecialchars($row["saleID"]) . "'><i class='fas fa-trash'></i></button>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>No entries found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            // Edit button click
            $(document).on('click', '.edit-btn', function() {
                var id = $(this).data('id');
                window.location.href = 'edit_sale.php?id=' + id;
            });

            // Delete button click
            $(document).on('click', '.delete-btn', function() {
                var id = $(this).data('id');
                if (confirm('Are you sure you want to delete this record?')) {
                    window.location.href = 'delete_sale.php?id=' + id;
                }
            });
        });
    </script>
</body>
</html>
