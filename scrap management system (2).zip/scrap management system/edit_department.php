<?php

include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $deptCode = $_POST['deptCode'];
    $deptName = $_POST['deptName'];
    $deptID = $_POST['deptID'];

    // Update the record in the database
    $sql = "UPDATE tbldepartmentmaster SET deptCode = :deptCode, deptName = :deptName WHERE deptID = :deptID";
    $command = $conn->prepare($sql);
    $command->bindParam(':deptCode', $deptCode);
    $command->bindParam(':deptName', $deptName);
    $command->bindParam(':deptID', $deptID);
    $command->execute();

    // Redirect back to the list page
    header("Location: department_master.php");
    exit();
}

// Fetch data for the record to be edited
$deptID = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$sql = "SELECT * FROM tbldepartmentmaster WHERE deptID = :deptID";
$command = $conn->prepare($sql);
$command->bindParam(':deptID', $deptID);
$command->execute();
$record = $command->fetch(PDO::FETCH_ASSOC);

if (!$record) {
    die("Record not found");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Department</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-4">
        <h3>Edit Department</h3>
        <form method="POST" action="edit_department.php">
            <input type="hidden" name="deptID" value="<?php echo htmlspecialchars($record['deptID']); ?>">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="deptCode">Department Code</label>
                    <input type="text" class="form-control" id="deptCode" name="deptCode" value="<?php echo htmlspecialchars($record['deptCode']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="deptName">Department Name</label>
                    <input type="text" class="form-control" id="deptName" name="deptName" value="<?php echo htmlspecialchars($record['deptName']); ?>" required>
                </div>
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
