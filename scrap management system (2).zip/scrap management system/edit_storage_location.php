<?php

include("db.php");

// Fetch the storage location data based on ID from URL
if (isset($_GET['id'])) {
    $stLocationID = $_GET['id'];
    
    $sql = "SELECT * FROM tblstoragelocation WHERE stLocationID = :stLocationID";
    $command = $conn->prepare($sql);
    $command->bindParam(':stLocationID', $stLocationID);
    $command->execute();
    $data = $command->fetch(PDO::FETCH_ASSOC);

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $stLocationName = $_POST['stLocationName'];

        $sql = "UPDATE tblstoragelocation SET stLocationName = :stLocationName WHERE stLocationID = :stLocationID";
        $command = $conn->prepare($sql);
        $command->bindParam(':stLocationName', $stLocationName);
        $command->bindParam(':stLocationID', $stLocationID);

        if ($command->execute()) {
            header("Location: storage_location_master.php");
            exit();
        } else {
            $error = "Error updating record.";
        }
    }
} else {
    echo "Invalid ID.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Storage Location</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-4">
        <h3>Edit Storage Location</h3>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="stLocationName">Storage Location Name</label>
                    <input type="text" class="form-control" id="stLocationName" name="stLocationName" value="<?php echo htmlspecialchars($data['stLocationName']); ?>" required>
                </div>
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                    <div class="form-group col-md-3">
                        <a href="storage_location_master.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
