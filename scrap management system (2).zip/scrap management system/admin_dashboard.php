<?php
session_start();
include('db.php'); // Replace with your database connection details

// Ensure only logged-in admins can access
if (!isset($_SESSION['admin_id'])) {
    header('Location: index.php');
    exit();
}

// Handle logout action
if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

// Fetch all records from tblzform
$query = "SELECT * FROM tblzform";
$result = $conn->query($query);

// Handle approve/reject/delete actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['approve'])) {
        $id = $_POST['zFormID'];
        $updateQuery = $conn->prepare("UPDATE tblzform SET status = 'Approved' WHERE zFormID = :id");
        $updateQuery->bindParam(':id', $id, PDO::PARAM_INT);
        $updateQuery->execute();
    } elseif (isset($_POST['reject'])) {
        $id = $_POST['zFormID'];
        $updateQuery = $conn->prepare("UPDATE tblzform SET status = 'Rejected' WHERE zFormID = :id");
        $updateQuery->bindParam(':id', $id, PDO::PARAM_INT);
        $updateQuery->execute();
    } elseif (isset($_POST['delete'])) {
        $id = $_POST['zFormID'];
        $deleteQuery = $conn->prepare("DELETE FROM tblzform WHERE zFormID = :id");
        $deleteQuery->bindParam(':id', $id, PDO::PARAM_INT);
        $deleteQuery->execute();
    }

    header('Location: admin_dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Z Form Management</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body class="bg-light">
<div class="container mt-5">
    <!-- Header Section -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="text-primary">Admin Dashboard - Z Form Management</h1>
        <form method="post">
            <button type="submit" name="logout" class="btn btn-danger">Logout</button>
        </form>
    </div>
    
    <!-- Table Section -->
    <div class="card shadow">
        <div class="card-body">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Z Form ID</th>
                        <th>Z Form No</th>
                        <th>Form Date</th>
                        <th>User ID</th>
                        <th>ST Location ID</th>
                        <th>Location</th>
                        <th>Category</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch(PDO::FETCH_ASSOC)): ?>
                    <tr>
                        <td><?= $row['zFormID'] ?></td>
                        <td><?= $row['zFormNo'] ?></td>
                        <td><?= $row['FormDate'] ?></td>
                        <td><?= $row['userID'] ?></td>
                        <td><?= $row['stLocationID'] ?></td>
                        <td><?= $row['location'] ?></td>
                        <td><?= $row['category'] ?></td>
                        <td>
                            <span class="badge 
                                <?= $row['status'] === 'Approved' ? 'bg-success' : 
                                    ($row['status'] === 'Rejected' ? 'bg-danger' : 'bg-secondary') ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="zFormID" value="<?= $row['zFormID'] ?>">
                                <button type="submit" name="approve" class="btn btn-success btn-sm me-2">Approve</button>
                                <button type="submit" name="reject" class="btn btn-warning btn-sm me-2">Reject</button>
                            </form>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="zFormID" value="<?= $row['zFormID'] ?>">
                                <button type="submit" name="delete" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Include Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
