<?php
session_start();

session_destroy();
$_SESSION["loginid"]="0";
header("Location: index.php");

?>
