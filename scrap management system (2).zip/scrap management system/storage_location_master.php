<?php
include("navbar.php");
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $stLocationName = $_POST['stLocationName'];

    // Insert form data into the database
    $sql = "INSERT INTO tblstoragelocation (stLocationName) VALUES (:stLocationName)";
    $command = $conn->prepare($sql);
    $command->bindParam(':stLocationName', $stLocationName);
    $command->execute();

    // Redirect to the same page to prevent resubmission
    header("Location: storage_location_master.php");
    exit();
}

// Fetch data from the database
$sql = "SELECT * FROM tblstoragelocation";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STORAGE LOCATION MASTER</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="container mt-4">
        <h3>STORAGE LOCATION MASTER</h3>
        <form id="storagelocationmaster" method="POST" action="storage_location_master.php">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="stLocationName">Storage Location Name</label>
                    <input type="text" class="form-control" id="stLocationName" name="stLocationName" required>
                </div>
                
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success" id="saveBtn">Save</button>
                    </div>
                   
                </div>
            </div>
        </form>

        <h3 class="mt-4">Location Entries</h3>
        <table class="table table-striped" id="tblstoragelocation">
            <thead>
                <tr>
                    <th>Storage Location ID</th>
                    <th>Storage Location</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($result)) {
                    foreach($result as $row) {
                        echo "<tr data-id='" . $row["stLocationID"] . "'>";
                        echo "<td>" . $row["stLocationID"] . "</td>";
                        echo "<td>" . $row["stLocationName"] . "</td>";
                        echo "<td>";
                        echo "<button class='btn btn-warning edit-btn' data-id='" . $row["stLocationID"] . "'><i class='fas fa-edit'></i></button> ";
                        echo "<button class='btn btn-danger delete-btn' data-id='" . $row["stLocationID"] . "'><i class='fas fa-trash'></i></button>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No entries found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).on('click', '.edit-btn', function() {
            var id = $(this).data('id');
            window.location.href = 'edit_storage_location.php?id=' + id;
        });

        $(document).on('click', '.delete-btn', function() {
            var id = $(this).data('id');
            if (confirm('Are you sure you want to delete this record?')) {
                $.ajax({
                    url: 'delete_storage_location.php',
                    type: 'POST',
                    data: { id: id },
                    success: function(response) {
                        if (response === "success") {
                            $('tr[data-id="' + id + '"]').remove();
                        } else {
                            alert('Error deleting record: ' + response);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error deleting record: ' + error);
                    }
                });
            }
        });
    </script>
</body>
</html>
