<?php
include("navbar.php");
include("db.php");

// Handle form submission for adding a new user
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userName = $_POST['userName'];
    $userID = $_POST['userID'];
    $password = $_POST['password'];
    $managerName = $_POST['managerName'];
    $deptID = $_POST['deptID'];

    // Insert form data into the database
    $sql = "INSERT INTO tblusermaster (userName, userID, password, managerName, deptID) VALUES (:userName, :userID, :password, :managerName, :deptID)";
    $command = $conn->prepare($sql);
    $command->bindParam(':userName', $userName);
    $command->bindParam(':userID', $userID);
    $command->bindParam(':password', $password);
    $command->bindParam(':managerName', $managerName);
    $command->bindParam(':deptID', $deptID);
    $command->execute();

    // Redirect to the same page to prevent resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Fetch data from the database
$sql = "SELECT * FROM tblusermaster";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Master</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-4">
        <h3>User Master</h3>
        <form id="userForm" method="POST" action="">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="userName">User Name</label>
                    <input type="text" class="form-control" id="userName" name="userName" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="userID">User ID</label>
                    <input type="text" class="form-control" id="userID" name="userID" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="managerName">Manager Name</label>
                    <input type="text" class="form-control" id="managerName" name="managerName" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="deptID">Department ID</label>
                    <input type="text" class="form-control" id="deptID" name="deptID" required>
                </div>
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success" id="saveBtn">Save</button>
                    </div>
                    
                </div>
            </div>
        </form>

        <h3 class="mt-4">User Entries</h3>
        <table class="table table-striped" id="userTable">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>User Name</th>
                    <th>Password</th>
                    <th>Manager Name</th>
                    <th>Department ID</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($result)) {
                    foreach($result as $row) {
                        echo "<tr data-id='" . htmlspecialchars($row["userID"]) . "'>";
                        echo "<td>" . htmlspecialchars($row["userID"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["userName"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["password"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["managerName"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["deptID"]) . "</td>";
                        echo "<td>";
                        echo "<button class='btn btn-warning edit-btn' data-id='" . htmlspecialchars($row["userID"]) . "'><i class='fas fa-edit'></i></button> ";
                        echo "<button class='btn btn-danger delete-btn' data-id='" . htmlspecialchars($row["userID"]) . "'><i class='fas fa-trash'></i></button>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No entries found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).on('click', '.edit-btn', function() {
            var id = $(this).data('id');
            window.location.href = 'edit_user.php?id=' + id;
        });

        $(document).on('click', '.delete-btn', function() {
            var id = $(this).data('id');
            if (confirm('Are you sure you want to delete this record?')) {
                $.ajax({
                    url: 'delete_user.php',
                    type: 'POST',
                    data: { id: id },
                    success: function(response) {
                        if (response === "success") {
                            $('tr[data-id="' + id + '"]').remove();
                        } else {
                            alert('Error deleting record: ' + response);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error deleting record: ' + error);
                    }
                });
            }
        });
    </script>
</body>
</html>
