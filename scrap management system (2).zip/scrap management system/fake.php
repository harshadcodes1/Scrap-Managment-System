<?php
include("navbar.php");
include("db.php");



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
   
    $stLocationName = $_POST['stLocationName'];

   
   
    
  
$sql = "SELECT * FROM tblstoragelocation";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STORAGE LOCATION MASTER</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-4">
        <h3>STORAGE LOCATION MASTER</h3>
        <form id="storagelocationmaster" method="POST" action="storage_location_master.php">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="stLocationName">Storage Location Name</label>
                    <input type="text" class="form-control" id="stLocationName" name="stLocationName" required>
                </div>
                
                
              <div class="form-row container mt-4">
                <div class="form-group col-md-3">
                    <button type="submit" class="btn btn-success" id="saveBtn">Save</button>
                </div>
                <div class="form- col-md-3 ">
                    <button type="reset" class="btn btn-warning">Refresh</button>
                </div>
            </div>
        </form>

        <h3 class="mt-4">Location Enteries</h3>
        <table class="table table-striped" id="tblstoragelocation" >
            <thead class="thead-dark">
                <tr>
                    <th>Storage Location ID
                    <th>Storage Location</th>
                    
                    
                    
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($result)) {
                    foreach($result as $row) {
                        echo "<tr>";
                      echo "<td>".$row["stLocationID"]."</td>";
                        echo "<td>".$row["stLocationName"]."</td>";
                        
					
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='12'>No entries found</td></tr>";
                }
                
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>

$('#fakeinserts').on('submit', function(event)){
        event.preventDefault();
        var form_data = $(this).serialize();
          $.ajax({
            url:"fakeinsert.php",
            method:"POST",
            data:form_data,
            success:function(data)
            {
            if(data=="1")
            {
            swal("Category Successfully Inserted!", {
                              icon: "success",
                            });
            }
            else
            {
             swal("Category Does Not Inserted!", {
                              icon: "error",
                            });
            }   

$sql = "SELECT * FROM tblstoragelocation";
$result = $conn->query($sql);
            }
          });
     document.getElementById("stLocationName").value ="";   
        
}; 







</script>

</body>
</html>