<?php
header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=studentlist.xls");
header("Pragma: no-cache");
header("Expires: 0");
?>

<html
<body style="text-align:center"> 
<table border="1" cellpadding="5px" cellspacing="5px" align="center" style="margin-top:10px">
<caption>Student Information</caption>
<tr>
<th>ID</th>
<th>Name</th>
<th>Address</th>
<th>Mobile No</th>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
</table>
</body>
</html>