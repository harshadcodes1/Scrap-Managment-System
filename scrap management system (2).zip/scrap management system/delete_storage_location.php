<?php
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $stLocationID = $_POST['id'];

    if (empty($stLocationID)) {
        echo "error: no id provided";
        exit();
    }

    $sql = "DELETE FROM tblstoragelocation WHERE stLocationID = :stLocationID";
    $command = $conn->prepare($sql);
    $command->bindParam(':stLocationID', $stLocationID);

    if ($command->execute()) {
        echo "success";
    } else {
        $errorInfo = $command->errorInfo();
        echo "error: " . $errorInfo[2];
    }
} else {
    echo "error: invalid request method";
}
?>
