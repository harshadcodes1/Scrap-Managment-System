<?php
include("navbar.php");
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $zFormID = $_POST['zFormID'];
    $zFormNo = $_POST['zFormNo'];
    $FormDate = $_POST['FormDate'];
    $userID = $_POST['userID'];
    $stLocationID = $_POST['stLocationID'];
    $location = $_POST['location'];
    $category = $_POST['category'];

    // Insert form data into the database
    try {
        $sql = "INSERT INTO tblzForm (zFormID, zFormNo, FormDate, userID, stLocationID, location, category)
                VALUES (:zFormID, :zFormNo, :FormDate, :userID, :stLocationID, :location, :category)";
        $command = $conn->prepare($sql);
        $command->bindParam(':zFormID', $zFormID);
        $command->bindParam(':zFormNo', $zFormNo);
        $command->bindParam(':FormDate', $FormDate);
        $command->bindParam(':userID', $userID);
        $command->bindParam(':stLocationID', $stLocationID);
        $command->bindParam(':location', $location);
        $command->bindParam(':category', $category);

        // Execute the command
        if ($command->execute()) {
            echo "<script>swal('Success', 'Form submitted successfully', 'success');</script>";
        } else {
            echo "<script>swal('Error', 'Form submission failed', 'error');</script>";
        }
    } catch (PDOException $e) {
        echo "<script>swal('Error', 'Form submission failed: " . $e->getMessage() . "', 'error');</script>";
    }
}

// Fetch data from the database
$sql = "SELECT * FROM tblzForm";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Z form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-4">
        <h3>Z form</h3>
        <form id="zform" method="POST" action="zform.php">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="zFormID">Z form ID</label>
                    <input type="text" class="form-control" id="zFormID" name="zFormID" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="zFormNo">Z form no</label>
                    <input type="text" class="form-control" id="zFormNo" name="zFormNo" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="FormDate">Date</label>
                    <input type="date" class="form-control" id="FormDate" name="FormDate" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="userID">User ID</label>
                    <input type="text" class="form-control" id="userID" name="userID" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="stLocationID">Storage Location ID</label>
                    <input type="text" class="form-control" id="stLocationID" name="stLocationID" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="location">Location</label>
                    <select id="location" class="form-control" name="location" required>
                        <option selected>Storage Location</option>
                        <option>Open Scrap</option>
                        <option>High Value Scrap</option>
                    </select>
                </div>
                <div class="form-group col-md-3">
                    <label for="category">Category</label>
                    <select id="category" class="form-control" name="category" required>
                        <option selected>Select category</option>
                        <option>processed</option>
                        <option>Components</option>
                    </select>
                </div>
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success" id="saveBtn">Save</button>
                    </div>
                    
                </div>
            </div>
        </form>

        <h3 class="mt-4">Z Form Entries</h3>
        <table class="table table-striped" id="zformTable">
            <thead>
                <tr>
                    <th>Z Form ID</th>
                    <th>Z Form No</th>
                    <th>Date</th>
                    <th>User ID</th>
                    <th>Storage Location ID</th>
                    <th>Location</th>
                    <th>Category</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->rowCount() > 0) {
                    while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                        echo "<tr data-id='" . htmlspecialchars($row["zFormID"]) . "'>";
                        echo "<td>" . htmlspecialchars($row["zFormID"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["zFormNo"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["FormDate"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["userID"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["stLocationID"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["location"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["category"]) . "</td>";
                        echo "<td>";
                        echo "<button class='btn btn-warning edit-btn' data-id='" . htmlspecialchars($row["zFormID"]) . "'><i class='fas fa-edit'></i></button> ";
                        echo "<button class='btn btn-danger delete-btn' data-id='" . htmlspecialchars($row["zFormID"]) . "'><i class='fas fa-trash'></i></button>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='8'>No entries found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).on('click', '.edit-btn', function() {
            var id = $(this).data('id');
            window.location.href = 'edit_zform.php?id=' + id;
        });

        $(document).on('click', '.delete-btn', function() {
            var id = $(this).data('id');
            if (confirm('Are you sure you want to delete this record?')) {
                $.ajax({
                    url: 'delete_zform.php',
                    type: 'POST',
                    data: { id: id },
                    success: function(response) {
                        if (response === "success") {
                            $('tr[data-id="' + id + '"]').remove();
                        } else {
                            alert('Error deleting record: ' + response);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error deleting record: ' + error);
                    }
                });
            }
        });
    </script>
</body>
</html>
