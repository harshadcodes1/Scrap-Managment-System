<?php
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userID = $_POST['id'];

    // Delete the record from the database
    $sql = "DELETE FROM tblusermaster WHERE userID = :userID";
    $command = $conn->prepare($sql);
    $command->bindParam(':userID', $userID);

    try {
        $command->execute();
        echo "success";
    } catch (PDOException $e) {
        echo "error: " . $e->getMessage();
    }
}
?>
