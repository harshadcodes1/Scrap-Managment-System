<?php

include('db.php');

// Fetch the sale data based on ID from URL
if (isset($_GET['id'])) {
    $saleID = $_GET['id'];
    
    $sql = "SELECT * FROM tblsaledetails WHERE saleID = :saleID";
    $command = $conn->prepare($sql);
    $command->bindParam(':saleID', $saleID);
    $command->execute();
    $data = $command->fetch(PDO::FETCH_ASSOC);

    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $saleDate = $_POST['saleDate'];
        $qty = $_POST['qty'];
        $invoiceNo = $_POST['invoiceNo'];
        $vendorName = $_POST['vendorName'];
        $material = $_POST['material'];

        $sql = "UPDATE tblsaledetails SET saleDate = :saleDate, qty = :qty, invoiceNo = :invoiceNo, vendorName = :vendorName, material = :material WHERE saleID = :saleID";
        $command = $conn->prepare($sql);
        $command->bindParam(':saleDate', $saleDate);
        $command->bindParam(':qty', $qty);
        $command->bindParam(':invoiceNo', $invoiceNo);
        $command->bindParam(':vendorName', $vendorName);
        $command->bindParam(':material', $material);
        $command->bindParam(':saleID', $saleID);

        if ($command->execute()) {
            header("Location: sale_entry.php");
            exit();
        } else {
            $error = "Error updating record.";
        }
    }
} else {
    echo "Invalid ID.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Sale Entry</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-4">
        <h3>Edit Sale Entry</h3>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="saleDate">Sale Date</label>
                    <input type="date" class="form-control" id="saleDate" name="saleDate" value="<?php echo htmlspecialchars($data['saleDate']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="invoiceNo">Invoice No</label>
                    <input type="text" class="form-control" id="invoiceNo" name="invoiceNo" value="<?php echo htmlspecialchars($data['invoiceNo']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="material">Material</label>
                    <input type="text" class="form-control" id="material" name="material" value="<?php echo htmlspecialchars($data['material']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="qty">Quantity</label>
                    <input type="text" class="form-control" id="qty" name="qty" value="<?php echo htmlspecialchars($data['qty']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="vendorName">Vendor Name</label>
                    <input type="text" class="form-control" id="vendorName" name="vendorName" value="<?php echo htmlspecialchars($data['vendorName']); ?>" required>
                </div>
            </div>
            <div class="form-row container mt-4">
                <div class="form-group col-md-3">
                    <button type="submit" class="btn btn-success">Update</button>
                </div>
                <div class="form-group col-md-3">
                    <a href="sale_entry.php" class="btn btn-secondary">Cancel</a>
                </div>
            </div>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
