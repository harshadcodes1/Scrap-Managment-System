<?php

$conn=new PDO("mysql:host=localhost;dbname=scrap_management_system","root","");

?>