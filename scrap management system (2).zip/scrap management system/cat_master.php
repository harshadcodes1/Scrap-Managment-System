




<?php
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $materialid = $_POST['materialID'];
    $materialname = $_POST['materialName'];
    $materialdescription = $_POST['materialDescription']; // corrected spelling
    $location = $_POST['location'];
    $category = $_POST['category'];
    $openingstock = $_POST['openingStock'];

    $sql = "INSERT INTO tblmaterialmaster (materialID, materialName, materialDescription, location, category, openingStock)
            VALUES ('$materialid', '$materialname', '$materialdescription', '$location', '$category', '$openingstock')";
    $command = $conn->prepare($sql);
    $command->execute();
}

$query = "SELECT * FROM tblmaterialmaster";
$result = $conn->query($query);
include("navbar.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add Font Awesome CSS here -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCRAP CAT MASTER</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="container mt-4">
        <h3>SCRAP CAT MASTER</h3>
        <form id="scrapcatmaster" method="POST" action="cat_master.php">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="materialID">Material ID</label>
                    <input type="text" class="form-control" id="materialID" name="materialID" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="materialName">Material Name</label>
                    <input type="text" class="form-control" id="materialName" name="materialName" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="materialDescription">Material Description</label>
                    <input id="materialDescription" class="form-control" name="materialDescription" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="location">Material Location</label>
                    <select id="location" class="form-control" name="location" required>
                        <option selected>Location</option>
                        <option>Open scrap</option>
                        <option>High Value Scrap</option>
                    </select>
                </div>
                <div class="form-group col-md-3">
                    <label for="category">Material Category</label>
                    <select id="category" class="form-control" name="category" required>
                        <option selected>Material Category</option>
                        <option>Processed Scrap</option>
                        <option>Components Scrap</option>
                    </select>
                </div>
                <div class="form-group col-md-3">
                    <label for="openingStock">Opening Stock</label>
                    <input type="text" class="form-control" id="openingStock" name="openingStock" required>
                </div>
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success" id="saveBtn">Save</button>
                    </div>
                   
                </div>
            </div>
        </form>
        <div class="container mt-4">
            <h3>Scrap Entries</h3>
            <table class="table table-striped" id="tblmaterialmaster">
                <thead>
                    <tr>
                        <th>Scrap CAT No</th>
                        <th>Scrap CAT Name</th>
                        <th>Material Description</th>
                        <th>Location</th>
                        <th>Category</th>
                        <th>Opening Stock</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($result)) {
                        foreach($result as $row) {
                            echo "<tr data-id='" . $row["materialID"] . "'>";
                            echo "<td>" . $row["materialID"] . "</td>";
                            echo "<td>" . $row["materialName"] . "</td>";
                            echo "<td>" . $row["materialDescription"] . "</td>";
                            echo "<td>" . $row["location"] . "</td>";
                            echo "<td>" . $row["category"] . "</td>";
                            echo "<td>" . $row["openingStock"] . "</td>";
                            echo "<td>";
                            echo "<button class='btn btn-warning edit-btn' data-id='" . $row["materialID"] . "'><i class='fas fa-edit'></i></button> ";
                            echo "<button class='btn btn-danger delete-btn' data-id='" . $row["materialID"] . "'><i class='fas fa-trash'></i></button>";
                            echo "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>No entries found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).on('click', '.edit-btn', function() {
            var id = $(this).data('id');
            window.location.href = 'edit_material.php?id=' + id;
        });

        $(document).on('click', '.delete-btn', function() {
            var id = $(this).data('id');
            
            if (confirm('Are you sure you want to delete this record?')) {
                $.ajax({
                    url: 'delete_material.php',
                    type: 'POST',
                    data: { id: id },
                    success: function(response) {
                        if (response === "success") {
                            $('tr[data-id="' + id + '"]').remove();
                        } else {
                            swal("error",{icon: "warning",});
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error deleting record: ' + error);
                    }
                });
            }
        });
    </script>
</body>
</html>
