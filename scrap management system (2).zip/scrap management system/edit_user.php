<?php
include("navbar.php");
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $userID = $_POST['userID'];
    $userName = $_POST['userName'];
    $password = $_POST['password'];
    $managerName = $_POST['managerName'];
    $deptID = $_POST['deptID'];

    // Update the record in the database
    $sql = "UPDATE tblusermaster SET userName = :userName, password = :password, managerName = :managerName, deptID = :deptID WHERE userID = :userID";
    $command = $conn->prepare($sql);
    $command->bindParam(':userID', $userID);
    $command->bindParam(':userName', $userName);
    $command->bindParam(':password', $password);
    $command->bindParam(':managerName', $managerName);
    $command->bindParam(':deptID', $deptID);
    $command->execute();

    // Redirect back to the list page
    header("Location: user_master.php");
    exit();
}

// Fetch data for the record to be edited
$userID = isset($_GET['id']) ? $_GET['id'] : '';
$sql = "SELECT * FROM tblusermaster WHERE userID = :userID";
$command = $conn->prepare($sql);
$command->bindParam(':userID', $userID);
$command->execute();
$record = $command->fetch(PDO::FETCH_ASSOC);

if (!$record) {
    die("Record not found");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-4">
        <h3>Edit User</h3>
        <form method="POST" action="edit_user.php">
            <input type="hidden" name="userID" value="<?php echo htmlspecialchars($record['userID']); ?>">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="userName">User Name</label>
                    <input type="text" class="form-control" id="userName" name="userName" value="<?php echo htmlspecialchars($record['userName']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" value="<?php echo htmlspecialchars($record['password']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="managerName">Manager Name</label>
                    <input type="text" class="form-control" id="managerName" name="managerName" value="<?php echo htmlspecialchars($record['managerName']); ?>" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="deptID">Department ID</label>
                    <input type="text" class="form-control" id="deptID" name="deptID" value="<?php echo htmlspecialchars($record['deptID']); ?>" required>
                </div>
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                    <div class="form-group col-md-3">
                        <a href="user_master.php" class="btn btn-warning">Cancel</a>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
