<?php
session_start();
require_once('TCPDF-6.2.26/tcpdf.php');
include("db.php");

// Ensure the user is logged in
if (empty($_SESSION['loginid'])) {
    header("Location: index.php");
    exit();
}

// Get Z Form ID
$zFormID = isset($_GET['zFormID']) ? intval($_GET['zFormID']) : 0;

// Fetch Z Form details
$zFormQuery = $conn->prepare("SELECT * FROM tblzform WHERE zFormID = :zFormID");
$zFormQuery->bindParam(':zFormID', $zFormID);
$zFormQuery->execute();
$zForm = $zFormQuery->fetch(PDO::FETCH_ASSOC);

if (!$zForm) {
    die("Error fetching Z Form details.");
}

// Create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Your Company');
$pdf->SetTitle('Z Form Details');
$pdf->SetSubject('Z Form Details');
$pdf->SetKeywords('TCPDF, PDF, Z Form, details');

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', 'B', 12);

// Company Logo
$pdf->Image('lauritz-knudsen-logo.png', 10, 10, 50);
$pdf->Ln(20);

// Title
$pdf->Cell(0, 10, 'Z Form Details', 0, 1, 'C');
$pdf->Ln(10);

// Z Form details
$pdf->SetFont('helvetica', '', 10);
$pdf->Cell(30, 10, 'Z Form No:', 1);
$pdf->Cell(0, 10, $zForm['zFormNo'], 1);
$pdf->Ln();
$pdf->Cell(30, 10, 'Form Date:', 1);
$pdf->Cell(0, 10, $zForm['FormDate'], 1);
$pdf->Ln();
$pdf->Cell(30, 10, 'Location:', 1);
$pdf->Cell(0, 10, $zForm['location'], 1);
$pdf->Ln();
$pdf->Cell(30, 10, 'Category:', 1);
$pdf->Cell(0, 10, $zForm['category'], 1);
$pdf->Ln();
$pdf->Cell(30, 10, 'Status:', 1);
$pdf->Cell(0, 10, $zForm['status'], 1);
$pdf->Ln();

// Close and output PDF document
$pdf->Output('z_form_details_' . $zFormID . '.pdf', 'D');
?>
