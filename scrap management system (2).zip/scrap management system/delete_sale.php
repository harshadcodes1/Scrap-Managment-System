<?php
include('navbar.php');
include('db.php');

// Check if the ID is set in the URL
if (isset($_GET['id'])) {
    $saleID = $_GET['id'];

    // Delete the sale entry
    $sql = "DELETE FROM tblsaledetails WHERE saleID = :saleID";
    $command = $conn->prepare($sql);
    $command->bindParam(':saleID', $saleID);

    if ($command->execute()) {
        header("Location: sale_entry.php");
        exit();
    } else {
        echo "Error deleting record.";
    }
} else {
    echo "Invalid ID.";
    exit();
}
?>
