<?php
session_start();
require_once('TCPDF-6.2.26/tcpdf.php');
include("db.php");

// Ensure the user is logged in
if (empty($_SESSION['loginid'])) {
    header("Location: index.php");
    exit();
}

// Fetch Z Form details
$zFormQuery = "SELECT * FROM tblzform ORDER BY FormDate DESC";
$result = $conn->query($zFormQuery);

// Create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Your Name');
$pdf->SetTitle('Z Form Details');
$pdf->SetSubject('Z Form Details');
$pdf->SetKeywords('TCPDF, PDF, Z Form, test, guide');

// Add a page
$pdf->AddPage();

// Set font
$pdf->SetFont('helvetica', 'B', 12);

// Title
$pdf->Cell(0, 10, 'Z Form Details', 0, 1, 'C');
$pdf->Ln(10);

// Table header
$pdf->SetFont('helvetica', 'B', 10);
$pdf->Cell(10, 10, 'SN', 1);
$pdf->Cell(30, 10, 'Z Form No', 1);
$pdf->Cell(30, 10, 'Form Date', 1);
$pdf->Cell(30, 10, 'Location', 1);
$pdf->Cell(30, 10, 'Category', 1);
$pdf->Cell(30, 10, 'Status', 1);
$pdf->Ln();

// Table rows
$pdf->SetFont('helvetica', '', 10);
$sn = 1;
while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
    $pdf->Cell(10, 10, $sn, 1);
    $pdf->Cell(30, 10, $row['zFormNo'], 1);
    $pdf->Cell(30, 10, $row['FormDate'], 1);
    $pdf->Cell(30, 10, $row['location'], 1);
    $pdf->Cell(30, 10, $row['category'], 1);
    $pdf->Cell(30, 10, $row['status'], 1);
    $pdf->Ln();
    $sn++;
}

// Close and output PDF document
$pdf->Output('z_form_details.pdf', 'D');
?>
