<?php
include("navbar.php");
include("db.php");

// Handle form submission for adding a new department
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $deptCode = $_POST['deptCode'];
    $deptName = $_POST['deptName'];

    // Insert form data into the database
    $sql = "INSERT INTO tbldepartmentmaster (deptCode, deptName) VALUES (:deptCode, :deptName)";
    $command = $conn->prepare($sql);
    $command->bindParam(':deptCode', $deptCode);
    $command->bindParam(':deptName', $deptName);
    $command->execute();

    // Redirect to the same page to prevent resubmission
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Fetch data from the database
$sql = "SELECT * FROM tbldepartmentmaster";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEPARTMENT MASTER</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-4">
        <h3>DEPARTMENT MASTER</h3>
        <form id="departmentmaster" method="POST" action="">
            <div class="form-row">
                <div class="form-group col-md-3">
                    <label for="deptCode">Department Code</label>
                    <input type="text" class="form-control" id="deptCode" name="deptCode" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="deptName">Department Name</label>
                    <input type="text" class="form-control" id="deptName" name="deptName" required>
                </div>
                <div class="form-row container mt-4">
                    <div class="form-group col-md-3">
                        <button type="submit" class="btn btn-success" id="saveBtn">Save</button>
                    </div>
                </div>
            </div>
        </form>

        <h3 class="mt-4">Department Entries</h3>
        <table class="table table-striped" id="departmentTable">
            <thead>
                <tr>
                    <th>Department ID</th>
                    <th>Department Code</th>
                    <th>Department Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (!empty($result)) {
                    foreach($result as $row) {
                        echo "<tr data-id='" . htmlspecialchars($row["deptID"]) . "'>";
                        echo "<td>" . htmlspecialchars($row["deptID"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["deptCode"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["deptName"]) . "</td>";
                        echo "<td>";
                        echo "<button class='btn btn-warning edit-btn' data-id='" . htmlspecialchars($row["deptID"]) . "'><i class='fas fa-edit'></i></button> ";
                        echo "<button class='btn btn-danger delete-btn' data-id='" . htmlspecialchars($row["deptID"]) . "'><i class='fas fa-trash'></i></button>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No entries found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).on('click', '.edit-btn', function() {
            var id = $(this).data('id');
            window.location.href = 'edit_department.php?id=' + id;
        });

        $(document).on('click', '.delete-btn', function() {
            var id = $(this).data('id');
            if (confirm('Are you sure you want to delete this record?')) {
                $.ajax({
                    url: 'delete_department.php',
                    type: 'POST',
                    data: { id: id },
                    success: function(response) {
                        if (response === "success") {
                            $('tr[data-id="' + id + '"]').remove();
                        } else {
                            alert('Error deleting record: ' + response);
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error deleting record: ' + error);
                    }
                });
            }
        });
    </script>
</body>
</html>
