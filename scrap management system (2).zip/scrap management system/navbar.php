
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .navbar {
            background-color: #007bff;
            transition: background-color 0.3s ease;
        }
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
            transform: perspective(500px) translateZ(0);
            transition: transform 0.3s ease, color 0.3s ease;
        }
        .nav-link {
            font-size: 1.1rem;
            margin-left: 10px;
            color: #ffffff !important;
            transform: perspective(500px) translateZ(0);
            transition: transform 0.3s ease, color 0.3s ease;
        }
        .nav-item.active .nav-link {
            font-weight: bold;
            background-color: #0056b3;
            border-radius: 5px;
            transform: perspective(500px) translateZ(10px);
        }
        .nav-item:hover .nav-link {
            background-color: #0056b3;
            border-radius: 5px;
            color: #000000 !important;
            transform: perspective(500px) translateZ(10px);
        }
        .btn-outline-light {
            border-color: #ffffff;
            color: #ffffff;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.3s ease;
        }
        .btn-outline-light:hover {
            background-color: #ffffff;
            color: #007bff;
            transform: perspective(500px) translateZ(10px);
        }
        .navbar-toggler {
            border-color: #ffffff;
        }
        .navbar-toggler-icon {
            color: #ffffff;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-sm">
        <a class="navbar-brand">Scrap Mgt. Sys.</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="cat_master.php">CatNo Master</a></li>
                <li class="nav-item"><a class="nav-link" href="storage_location_master.php">Storage Location</a></li>
                <li class="nav-item"><a class="nav-link" href="department_master.php">Department</a></li>
                <li class="nav-item"><a class="nav-link" href="user_master.php">User Master</a></li>
                <li class="nav-item"><a class="nav-link" href="zform.php">Z Form</a></li>
                <li class="nav-item"><a class="nav-link" href="sale_entry.php">Sale Entry</a></li>
               
            </ul>
            <button class="btn btn-outline-light my-2 my-sm-0" type="button" onclick="window.location.href='logout.php'">LogOut</button>
        </div>
    </nav>
</body>
</html>


