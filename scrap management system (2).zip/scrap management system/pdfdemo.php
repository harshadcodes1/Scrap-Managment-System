<?php

?>

<html
<body style="text-align:center"> 
<button>
<a href="downloadpdf.php" style="text-decoration:none;color:red;">Download PDF
</a>
</button>
<button>
<a href="downloadexcel.php" style="text-decoration:none;color:green;">Download Excel</a>
</button>
<table border="1" cellpadding="5px" cellspacing="5px" align="center" style="margin-top:10px">
<caption>Student Information</caption>
<tr>
<th>ID</th>
<th>Name</th>
<th>Address</th>
<th>Mobile No</th>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
<tr>
<td>101</td>
<td>Ganesh</td>
<td>Ahmednagar</td>
<td>9876543210</td>
</tr>
</table>
</body>
</html>