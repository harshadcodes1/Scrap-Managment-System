<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("db.php"); // Ensure this file uses MySQLi connection

// Establish MySQLi connection
$conn = new mysqli("localhost", "root", "", "scrap_management_system");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ensure the user is logged in
if (empty($_SESSION['loginid'])) {
    header("Location: index.php");
    exit();
}

// Fetch data for Z Form counts
$totalZForms = $approvedZForms = $pendingZForms = $rejectedZForms = 0;

// Queries for Z Form counts
$totalZFormsQuery = "SELECT COUNT(*) AS total FROM tblzform";
$approvedZFormsQuery = "SELECT COUNT(*) AS approved FROM tblzform WHERE status = 'Approved'";
$pendingZFormsQuery = "SELECT COUNT(*) AS pending FROM tblzform WHERE status = 'Pending'";
$rejectedZFormsQuery = "SELECT COUNT(*) AS rejected FROM tblzform WHERE status = 'Rejected'";

// Execute each query and handle errors
if ($result = $conn->query($totalZFormsQuery)) {
    $row = $result->fetch_assoc();
    $totalZForms = $row['total'];
} else {
    die("Error fetching total Z Forms: " . $conn->error);
}

if ($result = $conn->query($approvedZFormsQuery)) {
    $row = $result->fetch_assoc();
    $approvedZForms = $row['approved'];
} else {
    die("Error fetching approved Z Forms: " . $conn->error);
}

if ($result = $conn->query($pendingZFormsQuery)) {
    $row = $result->fetch_assoc();
    $pendingZForms = $row['pending'];
} else {
    die("Error fetching pending Z Forms: " . $conn->error);
}

if ($result = $conn->query($rejectedZFormsQuery)) {
    $row = $result->fetch_assoc();
    $rejectedZForms = $row['rejected'];
} else {
    die("Error fetching rejected Z Forms: " . $conn->error);
}

$statusFilter = isset($_GET['status']) ? $conn->real_escape_string($_GET['status']) : '';

// Adjust query based on filter
$zFormQuery = "SELECT * FROM tblzform";
if (!empty($statusFilter)) {
    $zFormQuery .= " WHERE status = '$statusFilter' ORDER BY FormDate DESC";
} else {
    $zFormQuery .= " ORDER BY FormDate DESC";
}

$result = $conn->query($zFormQuery);
if (!$result) {
    die("Error fetching Z Form details: " . $conn->error);
}

include("navbar.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scrap Mgt. Sys. - Dashboard</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles_user.css">
</head>
<body>
    <div class="container mt-5">
        <!-- Z Form Counts -->
        <div class="row">
            <div class="col-md-3">
                <a href="?status=" class="text-decoration-none">
                    <div class="card text-center text-primary">
                        <div class="card-body">
                            <h5 class="card-title">Total Z Forms</h5>
                            <p class="card-text display-4"><?= htmlspecialchars($totalZForms) ?></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="?status=Approved" class="text-decoration-none">
                    <div class="card text-center text-success">
                        <div class="card-body">
                            <h5 class="card-title">Approved Z Forms</h5>
                            <p class="card-text display-4"><?= htmlspecialchars($approvedZForms) ?></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="?status=Pending" class="text-decoration-none">
                    <div class="card text-center text-warning">
                        <div class="card-body">
                            <h5 class="card-title">Pending Z Forms</h5>
                            <p class="card-text display-4"><?= htmlspecialchars($pendingZForms) ?></p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3">
                <a href="?status=Rejected" class="text-decoration-none">
                    <div class="card text-center text-danger">
                        <div class="card-body">
                            <h5 class="card-title">Rejected Z Forms</h5>
                            <p class="card-text display-4"><?= htmlspecialchars($rejectedZForms) ?></p>
                        </div>
                    </div>
                </a>
            </div>
        </div>

        <!-- Z Form Details Table -->
        <div class="row mt-4">
            <div class="col-md-12">
                <h2>Z Form Details</h2>
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>SN</th>
                            <th>Z Form No</th>
                            <th>Form Date</th>
                            <th>Location</th>
                            <th>Category</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sn = 1;
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . htmlspecialchars($sn) . "</td>
                                    <td>" . htmlspecialchars($row['zFormNo']) . "</td>
                                    <td>" . htmlspecialchars($row['FormDate']) . "</td>
                                    <td>" . htmlspecialchars($row['location']) . "</td>
                                    <td>" . htmlspecialchars($row['category']) . "</td>
                                    <td>" . htmlspecialchars($row['status']) . "</td>
                                    <td>
                                        <a href='generate_individual_pdf.php?zFormID=" . htmlspecialchars($row['zFormID']) . "' class='btn btn-secondary'>Download PDF</a>
                                    </td>
                                  </tr>";
                            $sn++;
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
