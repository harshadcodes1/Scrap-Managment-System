<?php
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];

    // Prepare the SQL statement to delete the record
    $sql = "DELETE FROM tblzForm WHERE zFormID = :id";
    $command = $conn->prepare($sql);
    $command->bindParam(':id', $id);

    // Execute the command and check if it was successful
    if ($command->execute()) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
