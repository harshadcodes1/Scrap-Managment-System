<?php
require_once('tcpdf_min/tcpdf_min/tcpdf.php');  

class MYPDF extends TCPDF {
    //Page header
    public function Header() {

    }

    // Page footer
    public function Footer() {

    }
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetTitle('Student List');
$pdf->SetSubject('Student List');

// remove default header/footer
$pdf->setPrintHeader(true);
$pdf->setPrintFooter(true);

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(5, 5, 5);

$pdf->SetTopMargin(5);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, 10);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)

// set font
$pdf->SetFont('times', '', 10);

// add a page
$pdf->AddPage('P', 'A4');

// PDF DATA CODE

$width=$pdf->GetPageWidth(); // Width of Current Page
$height=$pdf->GetPageHeight(); // Height of Current Page
$gap=5; // Gap between line and border , change this value

$pdf->Line($gap,$gap,$width-$gap,$gap); // Horizontal line at top
$pdf->Line($gap, $height-$gap,$width-$gap,$height-$gap); // Horizontal line at bottom
$pdf->Line($gap, $gap,$gap,$height-$gap); // Vetical line at left 
$pdf->Line($width-$gap, $gap,$width-$gap,$height-$gap); // Vetical line at Right

$output='
<html>
<body> 
<table border="1" cellpadding="5px" cellspacing="5px">
<tr>
<th style="width:25%">z Form ID</th>
<th style="width:25%">z Form No</th>
<th style="width:25%">z Form Date</th>
<th style="width:25%">Storage Location ID</th>
<th style="width:25%">Location</th>
<th style="width:25%">Category</th>







</tr>
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr>
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr >
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr>
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr>
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr>
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr>
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr>
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr>
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr>
<tr>
<td style="width:25%">101</td>
<td style="width:25%">Ganesh</td>
<td style="width:25%">Ahmednagar</td>
<td style="width:25%">9876543210</td>
</tr>
</table>
</body>
</html>
';

$filename="studentlist.pdf";
$pdf->writeHTML($output);  
$pdf->Output($filename, 'D'); 

?>