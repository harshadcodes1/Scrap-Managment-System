<?php
session_start();
error_reporting(0);
include("db.php");

// Redirect to the dashboard if already logged in
if (strlen($_SESSION["loginid"]) != 0) {
    if ($_SESSION["role"] === "admin") {
        header("location:admin_dashboard.php");
    } else {
        header("location:dashboard.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scrap Management System</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-12 d-flex justify-content-between align-items-center">
                <img src="lauritz-knudsen-logo.png" alt="Lauritz Knudsen Logo" class="logo">
                <button class="btn btn-warning refresh-btn" onclick="location.reload()">Refresh</button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center header-content">
                <h1>SCRAP MANAGEMENT</h1>
                <h3>Project Under <span class="font-italic">"Innovate To Digitize"</span> By ASW Central Stores</h3>
                <p class="font-weight-bold">“When Seen Well, Waste Seems Wealth”</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7">
                <img src="loginimg.png" alt="Scrap Management" class="img-fluid">
            </div>
            <div class="col-md-5">
                <div class="login-box">
                    <img src="lauritz-knudsen-logo.png" alt="Lauritz Knudsen Logo" class="login-logo">
                    <form method="POST">
                        <div class="form-group">
                            <label for="txtusername">User Name</label>
                            <input type="text" class="form-control" id="txtusername" name="txtusername" placeholder="Enter User name" required>
                        </div>
                        <div class="form-group">
                            <label for="txtpassword">Password</label>
                            <input type="password" class="form-control" id="txtpassword" name="txtpassword" placeholder="Enter Password" required>
                        </div>
                        <button type="submit" class="btn btn-success btn-block" name="btnlogin" id="btnlogin">LOGIN</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php

// Handle login form submission
if (isset($_POST["btnlogin"])) {
    $userName = $_POST['txtusername'];
    $password = $_POST['txtpassword'];

    $query = "SELECT * FROM tbllogindetails WHERE userName = :userName AND password = :password";
    $command = $conn->prepare($query);
    $command->bindParam(':userName', $userName);
    $command->bindParam(':password', $password);
    $command->execute();
    $resultset = $command->fetchAll();

    if (count($resultset) > 0) {
        foreach ($resultset as $row) {
            $_SESSION['loginid'] = $row["UserID"];
            $_SESSION['loginname'] = $row["UserName"];
            $_SESSION['role'] = $row["Role"]; // Assuming 'Role' column defines 'admin' or 'user'

            // Redirect based on role
            if ($_SESSION['role'] === "admin") {
                header("location:admin_dashboard.php");
            } else {
                header("location:dashboard.php");
            }
        }
    } else {
        echo "<script>alert('Login Failed');</script>";
        header("location:in.php");
    }
}
?>
