<?php
include("navbar.php");
include("db.php");



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
   
    $stLocationName = $_POST['stLocationName'];

   
   
    
  

    // Insert form data into the database
    $sql = "INSERT INTO tblstoragelocation (,stLocationName)
            VALUES ('$stLocationName')";
$command=$conn->prepare($sql);
if($command->execute())
{
	
echo "1";

	else 
		
echo 	"0";
	
	
}		
    }


// Fetch data from the database

?>