<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("db.php");

// Handle logout
if (isset($_GET['logout']) && $_GET['logout'] == 1) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}

// Check if session login ID is set
if (isset($_SESSION["loginid"]) && !empty($_SESSION["loginid"])) {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scrap Management System</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-fluid">
        <div class="row mt-4">
            <div class="col-md-12 d-flex justify-content-between align-items-center">
                <img src="lauritz-knudsen-logo.png" alt="Lauritz Knudsen Logo" class="logo">
                <button class="btn btn-warning refresh-btn" onclick="location.reload()">Refresh</button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center header-content">
                <h1>SCRAP MANAGEMENT</h1>
                <h3>Project Under <span class="font-italic">"Innovate To Digitize"</span> By ASW Central Stores</h3>
                <p class="font-weight-bold">“When Seen Well, Waste Seems Wealth”</p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7">
                <img src="loginimg.png" alt="Scrap Management" class="img-fluid">
            </div>
            <div class="col-md-5">
                <div class="login-box">
                    <img src="lauritz-knudsen-logo.png" alt="Lauritz Knudsen Logo" class="login-logo">
                    
                    <!-- User Login Form -->
                    <form method="POST">
                        <div class="form-group">
                            <label for="txtusername">User Name</label>
                            <input type="text" class="form-control" id="txtusername" name="txtusername" placeholder="Enter User name" required>
                        </div>
                        <div class="form-group">
                            <label for="txtpassword">Password</label>
                            <input type="password" class="form-control" id="txtpassword" name="txtpassword" placeholder="Enter Password" required>
                        </div>
                        <button type="submit" class="btn btn-success btn-block" name="btnlogin" id="btnlogin">User Login</button>
                    </form>

                    <hr>

                    <!-- Admin Login Form -->
                    <form method="POST">
                        <div class="form-group">
                            <label for="adminusername">Admin Username</label>
                            <input type="text" class="form-control" id="adminUsername" name="adminUsername" placeholder="Enter Admin Username">
                        </div>
                        <div class="form-group">
                            <label for="adminpassword">Admin Password</label>
                            <input type="password" class="form-control" id="adminPassword" name="adminPassword" placeholder="Enter Admin Password">
                        </div>
                        <button type="submit" class="btn btn-warning btn-block" name="btnadminlogin" id="btnadminlogin">Admin Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
// Handle User Login
if (isset($_POST["btnlogin"])) {
    $userName = $_POST['txtusername'];
    $password = $_POST['txtpassword'];

    $query = "SELECT * FROM tbllogindetails WHERE userName = :userName AND password = :password";
    $command = $conn->prepare($query);
    $command->bindParam(':userName', $userName);
    $command->bindParam(':password', $password);
    $command->execute();
    $resultset = $command->fetchAll();

    if (count($resultset) > 0) {
        foreach ($resultset as $row) {
            $_SESSION['loginid'] = $row["userID"];
            $_SESSION['loginname'] = $row["userName"];
            header("Location: dashboard.php");
            exit();
        }   
    } else {
        echo "<script>alert('User Login Failed');</script>";
    }
}

// Handle Admin Login
if (isset($_POST["btnadminlogin"])) {
    $adminUsername = $_POST['adminUsername'];
    $adminPassword = $_POST['adminPassword'];

    $query = "SELECT * FROM admin WHERE adminUsername = :adminUsername AND adminPassword = :adminPassword";
    $command = $conn->prepare($query);
    $command->bindParam(':adminUsername', $adminUsername);
    $command->bindParam(':adminPassword', $adminPassword);
    $command->execute();
    $resultset = $command->fetchAll();

    if (count($resultset) > 0) {
        foreach ($resultset as $row) {
            $_SESSION['admin_id'] = $row["admin_id"];
            $_SESSION['admin_name'] = $row["adminUsername"];
            header("Location: admin_dashboard.php");
            exit();
        }
    } else {
        echo "<script>alert('Admin Login Failed');</script>";
    }
}
?>
